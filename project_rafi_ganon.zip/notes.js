function Note(text, date, time, priority, darkMode) {
    this.text = text;
    this.date = date;
    this.time = time;
    this.priority = priority;
    this.darkMode = darkMode;
}